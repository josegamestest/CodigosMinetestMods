Minetest Game mod: dye
======================
See license.txt for license information.
See init.lua for documentation.

Authors of source code
----------------------
Originally by Perttu Ahola (celeron55) <celeron55@gmail.com> (MIT)
Various Minetest developers and contributors (MIT)

Authors of media (textures)
---------------------------
Perttu Ahola (celeron55) <celeron55@gmail.com> (CC BY-SA 3.0)
